<?php

?>
    </main> 
    
    <div class="admin-footer">
        <p>&copy; 2025 F.Style Admin Dashboard | Dùng cho mục đích quản lý nội bộ.</p>
    </div>

    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Custom Admin JS -->
    <script src="Public/Js/admin.js"></script>

</body>
</html>