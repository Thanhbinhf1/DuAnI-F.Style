</main> <footer> 
        <div class="footer-content">
            <p>&copy;  2025 Lương Hữu Luyến - Nguyễn Thanh Bình - Trương Quang Quy - Phạm Xuân Ái</p>
        </div>
    </footer>
</body>
</html>