<?php

?>
    </main> 
    
    <div class="admin-footer">
        <p>&copy; 2025 F.Style Admin Dashboard | Dùng cho mục đích quản lý nội bộ.</p>
    </div>
</body>
</html>